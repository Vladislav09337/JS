import { generateBooks } from './scripts/bookGenerator.js';

let books = [];

const tableBody = document.getElementById('table-body');
const countEl = document.getElementById('count');
const searchInput = document.getElementById('search');
const form = document.getElementById('book-form');

async function loadBooks() {
  try {
    books = await generateBooks(10);
    render();
  } catch (error) {
    console.error('Ошибка загрузки книг:', error);
    alert('Не удалось загрузить книги');
  }
}

function render() {
  tableBody.innerHTML = '';
  const searchTerm = searchInput.value.toLowerCase().trim();
  const filtered = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm) ||
    book.author.toLowerCase().includes(searchTerm)
  );

  filtered.forEach(book => {
    const tr = document.createElement('tr');
    tr.dataset.id = book.id;

    tr.innerHTML = `
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.genre || ''}</td>
      <td>${book.year || ''}</td>
      <td>${book.rating || ''}</td>
      <td>
        <button class="edit">Редактировать</button>
        <button class="delete">Удалить</button>
      </td>
    `;

    tableBody.appendChild(tr);
  });

  countEl.textContent = filtered.length;
}

tableBody.addEventListener('click', function (e) {
  const tr = e.target.closest('tr');
  if (!tr) return;
  const id = tr.dataset.id;

  if (e.target.classList.contains('delete')) {
    if (confirm('Удалить книгу?')) {
      books = books.filter(book => book.id !== id);
      render();
    }
  }

  if (e.target.classList.contains('edit')) {
    const book = books.find(b => b.id === id);
    fillForm(book);
  }
});

function normalizeBook(data) {
  return {
    title: (data.title || '').trim(),
    author: (data.author || '').trim(),
    genre: (data.genre || '').trim(),
    year: data.year ? Number(data.year) : null,
    rating: data.rating ? Number(data.rating) : null
  };
}

form.addEventListener('submit', function (e) {
  e.preventDefault();
  const formData = new FormData(form);
  const data = Object.fromEntries(formData);
  const bookData = normalizeBook(data);

  if (data.id) {
    const book = books.find(b => b.id === data.id);
    Object.assign(book, bookData);
  } else {
    books.push({
      id: crypto.randomUUID(),
      ...bookData
    });
  }

  form.reset();
  form.querySelector('[name="id"]').value = '';
  render();
});

function fillForm(book) {
  const fields = ['id', 'title', 'author', 'genre', 'year', 'rating'];
  fields.forEach(field => {
    const input = form.querySelector(`[name="${field}"]`);
    if (input) input.value = book[field] || '';
  });
}

searchInput.addEventListener('input', render);

document.getElementById('export').addEventListener('click', function () {
  const dataStr = JSON.stringify(books, null, 2);
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'books.json';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('reload').addEventListener('click', loadBooks);

loadBooks();