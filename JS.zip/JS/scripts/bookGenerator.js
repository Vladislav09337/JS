const SUBJECTS = [
  "fantasy", "science_fiction", "mystery", "romance", 
  "biography", "history", "science", "programming"
];

function randomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

export async function generateBooks(count = 10) {
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const subject = randomItem(SUBJECTS);
      const url = `https://openlibrary.org/subjects/${subject}.json?limit=50`;

      const response = await fetch(url);
      if (!response.ok) continue;

      const data = await response.json();
      if (!data.works || !Array.isArray(data.works)) continue;

      const filtered = data.works
        .filter(book => book.title && book.authors && book.authors.length > 0)
        .slice(0, count);

      const books = filtered.map(book => ({
        id: crypto.randomUUID(),
        title: book.title,
        author: book.authors.map(a => a.name).join(", "),
        genre: subject,
        year: book.first_publish_year || null,
        rating: parseFloat((3 + Math.random() * 2).toFixed(1))
      }));

      if (books.length > 0) return books;
    } catch (err) {
      console.warn("Попытка не удалась:", err);
    }
  }

  throw new Error("Не удалось сгенерировать книги");
}